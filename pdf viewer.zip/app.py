from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__)
pdfs_dir = 'pdfs'
@app.route('/')
def index():
    pdf_files = os.listdir(pdfs_dir)
    pdf_files = [filename for filename in pdf_files if filename.endswith('.pdf')]
    return render_template('index.html', pdf_files=pdf_files)

@app.route('/pdf/<filename>')
def display_pdf(filename):
    return render_template('pdf_viewer.html', pdf_filename=filename)

@app.route('/pdfs/<path:filename>')
def pdf(filename):
    return send_from_directory('pdfs', filename)

if __name__ == '__main__':
    app.run(debug=True)
