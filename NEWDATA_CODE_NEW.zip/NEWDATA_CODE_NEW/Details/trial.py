import random
from datetime import datetime, timedelta, date

# Generate a random effective date for a policy
start_year = 2010
end_year = 2022
random_year = random.randint(start_year, end_year)
month = random.randint(1, 12)
day = random.randint(1, 28)
policy_effective_date = date(random_year, month, day)

# Define your start and end dates
current_date = datetime.now()
end_date = current_date.date()

# Calculate the difference in days between the start and end dates
days_difference = (end_date - policy_effective_date).days

# Generate a random number of days to add to the start date
random_days = random.randint(0, days_difference)

# Calculate the random date by adding the random number of days to the start date
random_date = policy_effective_date + timedelta(days=random_days)

print("Policy Effective Date:", policy_effective_date)
print("Random Date Between {} and {}: {}".format(policy_effective_date, end_date, random_date))
