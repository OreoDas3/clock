from Rules.lib import *
from Rules.calculate_policy_status import *
from Rules.under_writing import *
from Rules.generate_name import *
def random_values():
    policy_number = fake.random_int(min=10000, max=99999)
    start_year = 2010
    end_year=2022
    random_year = random.randint(start_year, end_year)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    policy_effective_date = date(random_year, month, day)
    policy_effective_date1=policy_effective_date.strftime("%Y-%m-%d")
    medical_history=fake.random_element(elements=('Diabetis','Cancer'))
    policy_expiry_date=policy_effective_date.replace(year=random_year+20)
    policy_expiry_date1=policy_expiry_date.strftime("%Y-%m-%d")
    
    given_name,Surname=(generate_name().split())
    #Surname=fake.random_element(elements=('Smith','Willis','Stewart','Christie','Austen','Stones','Harvey','Peter','Williams','Wallace'))
    #given_name=fake.random_element(elements=('Alice', 'Bob', 'Charlie', 'David', 'Ella', 'Frank', 'Grace', 'Hannah', 'Isaac', 'Jessica', 'Kevin', 'Lily', 'Mike', 'Nora', 'Oliver', 'Patricia', 'Quincy', 'Rachel', 'Samuel', 'Taylor', 'Ursula', 'Vincent', 'Wendy', 'Xavier', 'Yvonne', 'Zachary', 'Andrew', 'Sophia', 'Emily'))
    min_birth_year = random_year - 70  # 60 years before the effective date
    max_birth_year = random_year - 20   # 20 years before the effective date
    random_birth_year = random.randint(min_birth_year, max_birth_year)
    random_birth_month = random.randint(1, 12)
    random_birth_day = random.randint(1, 28)
    birthdate = date(random_birth_year, random_birth_month, random_birth_day)
    Gender=fake.random_element(elements=('M','F'))
    occupation=fake.random_element(elements=('Engineer','Teacher','Doctor','Beautician','Interior Decorator','Lawyer','Electrician','Policeman','CSR','Researcher'))
    address_type=fake.random_element(elements=('Residential','Non-Residential'))
    address=fake.random_element(elements=('3543 Upland Avenue','1715 Ashmor Drive',' 3656 Neuport Lane','1283 Bobcat Drive',' 1939 Longview Avenue','2815 Burke Street',' 728 Pooh Bear Lane',' 4719 Farland Avenue','1373 Oliver Street','4586 Ritter Street','881 Gladwell Street','2610 New Street'))
    city=fake.city()
    state_province=fake.state_abbr()
    postal_code=fake.zipcode()
    Face_Amt=(random.randint(10,1000)*1000)
    Premium_Amt=fake.random_int(100,999)
    Premium_Frequency=fake.random_element(elements=('Yearly','Half-Yearly','Quarterly','Monthly'))
    time_range=policy_expiry_date-policy_effective_date
    random_days=random.randint(0,time_range.days)
    
    #First_Unpaid_premium_date=policy_effective_date+timedelta(days=random_days)
    # Calculate the difference in days between the start and end dates
    current_date = datetime.now()
    end_date = current_date.date()
    days_difference = (end_date - policy_effective_date).days
    # Generate a random number of days to add to the start date
    random_days = random.randint(0, days_difference)
    # Calculate the random date by adding the random number of days to the start date
    First_Unpaid_premium_date = policy_effective_date + timedelta(days=random_days)
    First_Unpaid_premium_date1=First_Unpaid_premium_date.strftime("%Y-%m-%d")
    
    age = policy_effective_date.year - birthdate.year - ((policy_effective_date.month, policy_effective_date.day) < (birthdate.month, birthdate.day))
    if 18<=age<=60:
        policy_status = calculate_policy_status(policy_effective_date1, policy_expiry_date1, Premium_Frequency, First_Unpaid_premium_date1)
    elif 60<age<=65:
        policy_status="Claim settled"
    else:
        policy_status="Declined"
    under_writing_decision=(under_writing(policy_status))
    if under_writing_decision=="Declined":
        policy_status="Declined"
    carrier_name=fake.random_element(elements=("The Guardian Life Insurance Company of America","The Chubb Corporation"))
    carrier_code=fake.random_element(elements=('abc123','def456','ghi789','jkl012','mn0345','pqr678','stu987','vwx908'))
    if policy_status!='Claim settled':
        Date_of_Death="-"
        Date_of_Claim_settlement="-"
        Cause_of_Death="-"
    else:
        current_year=datetime.now().year
        Date_of_Death=date(current_year,month=policy_effective_date.month,day=policy_effective_date.day)
        if policy_effective_date.month<12:
            Date_of_Claim_settlement=date(current_year,month=policy_effective_date.month+1,day=policy_effective_date.day)
            
        else:
            Date_of_Claim_settlement=date(current_year,month=policy_effective_date.month,day=policy_effective_date.day)    
        Cause_of_Death=fake.random_element(elements=('Heart Attack','Diabetis','Cancer','Accident'))
    if policy_status=='Declined':
        First_Unpaid_premium_date='-'
        policy_expiry_date='-'
    Agency_name=fake.random_element(elements=('American Family Insurance','Lincoln National Corporation ','General Reinsurance Corporation ',' Willis Towers Watson PLC   ',' AmTrust Financial Services ','USI Insurance Services LLC   '))
    Agent_code=fake.random_element(elements=('abc123','def456','ghi789','jkl012','mn0345','pqr678','stu987','vwx908'))
    Income=(random.randint(1000,3000)*100)
    smoking_status=fake.random_element(elements=('Smoker','Non-Smoker'))
    Drinking_status=fake.random_element(elements=('Drinker','Non-Drinker'))
    family_medical_history=fake.random_element(elements=('No Significant History','Significant History'))
    height=(random.randint(160,190))  
    weight=(random.randint(60,80))
    mvr=fake.random_element(elements=('Clean','Minor Violations','Major Violations'))
    mib=fake.random_element(elements=('Positive Report','Negative Report'))
    value = fake.random_int(min=600, max=880)
    #value=fake.random_element(elements=('average','Excellent','good'))

    social_media=fake.random_element(elements=('Active','Non Active'))
    #fake.random_element(elements=('presence','non presence'))
    policy_status_final=policy_status
    return (policy_number, random_year, month, day, policy_effective_date, medical_history, policy_expiry_date, Surname, given_name, birthdate, Gender, occupation, address_type, city, state_province, postal_code, Face_Amt, Premium_Amt, Premium_Frequency, First_Unpaid_premium_date, age, policy_status_final, under_writing_decision, Income, smoking_status, Drinking_status, family_medical_history, height, weight, mvr, mib, value, social_media, Date_of_Death, Date_of_Claim_settlement, Cause_of_Death)

