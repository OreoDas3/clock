def calculate_MVR_value(mvr):              
    if mvr=="Clean":
        return "Low Risk"
    elif mvr=="Minor Violations" :
        return "Medium Risk"
    else:
        return "High Risk"