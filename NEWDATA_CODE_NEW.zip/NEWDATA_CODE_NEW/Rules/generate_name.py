from faker import Faker
import random
import string

# Create a Faker instance
fake = Faker()
def generate_name():
    while True:
        # Generate a random name using Faker
        name = fake.name()
        
        # Check if the name has exactly 2 characters
        if len(name.split()) == 2:
            return name
        