def calculate_occupation_risk(occpation):
    if occpation=="Policeman":
        return 0.4
    elif occpation=="Electrician":
        return 0.5
    else:
        return 0.9