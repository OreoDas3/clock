def calculate_medical_history(family_medical_history):
     if family_medical_history=="Significant History":
         return 0.4
     else:
         return 0.9