def calculate_value(age):
    if age<=35:
        return "Excellent"
    elif age>=36 and age<=45:
        return "Very Good"
    elif age>=46 and age<=55:
        return "Good"
    elif age>=56 and age<=65:
        return "Average"
    else:
        return "Bad"