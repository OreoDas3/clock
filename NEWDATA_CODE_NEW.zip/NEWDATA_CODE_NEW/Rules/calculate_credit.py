def calculate_credit(parameter_value):
    
    # Calculate the score based on a linear scale
    min_value = 600
    max_value = 880
    min_score = 0.1
    max_score = 1.0

    normalized_value = (int(parameter_value) - min_value) / (max_value - min_value)
    score = min_score + normalized_value * (max_score - min_score)
    score=round(score, 1)
    
    if 600 <= parameter_value < 700:
        return "Average",score
    elif 700 <= parameter_value < 800:
        return "Good",score
    elif 800 <= parameter_value <= 880:
        return "Excellent",score
    return "Invalid",score