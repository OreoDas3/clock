from Rules.lib import *
def bmi(height,weight):
    bmi=weight/((height/100)**2)
    return(bmi)      
def calculate_height(height,weight):
   bmi1=bmi(height, weight)
   if bmi1>18.5 and bmi1<25:
        return "Normal"
   elif bmi1>=25 and bmi1<30:
        return "High"
   elif bmi1<=18.5:
        return "Low"
   elif bmi1>=30:
        return "Very high"
def calculate_height_value(height,weight):
    bmi1=bmi(height, weight)
    if bmi1>=18.5 and bmi1<=24.9:
        return fake.random_element(elements=('0.8','0.9','1.0'))
    elif bmi1>=25 and bmi1<=29.9:
        return fake.random_element(elements=('0.5','0.6','0.7'))
    elif bmi1<=18.5:
        return "0.4"
    elif bmi1>=30:
        return fake.random_element(elements=('0.3','0.2','0.1'))
    else:
        return "hiii"