def calculate_MVR(mvr):              
    if mvr=="Clean":
        return 0.8
    elif mvr=="Minor Violations" :
        return 0.5
    else:
        return 0.4