from Rules.lib import *
def calculate_score(age):
    if  age<=35:
        return fake.random_element(elements=('0.9','1'))
    elif age>=36 and age<=45:
        return fake.random_element(elements=('0.8','0.7'))
    elif age>=46 and age<=55:
        return fake.random_element(elements=('0.5','0.6'))
    elif age>=56 and age<=65:
        return  0.4
    else:
        return fake.random_element(elements=('0.2','0.3'))