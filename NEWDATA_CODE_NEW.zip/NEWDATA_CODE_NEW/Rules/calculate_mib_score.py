def calculate_mib_score(value):
    if value=="Excellent":
        return 0.9
    elif value=="Good":
        return 0.6
    else:
        return 0.4