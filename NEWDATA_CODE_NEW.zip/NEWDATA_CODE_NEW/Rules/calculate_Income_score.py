from Rules.lib import *
def calculate_Income_score(Income):
    if Income>=200000:
        return fake.random_element(elements=('0.9','1'))
    elif Income>=150000 and Income<199999:
        return fake.random_element(elements=('0.8','0.7'))
    elif Income>=100000 and Income<149000:
        return fake.random_element(elements=('0.5','0.6'))
    elif Income>=60000 and Income<100000:
        return fake.random_element(elements=('0.3','0.7'))
    else:
        return 0