def calculate_smoking_status(smoking_status):
    if smoking_status=="Smoker":
        return 0.5
    else:
        return 0.9