from random import *
from datetime import datetime,timedelta
from datetime import date
from dateutil.relativedelta import relativedelta
from faker import Faker
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from faker.providers import DynamicProvider
import random
fake=Faker()
from openpyxl import Workbook
from openpyxl.styles import Font