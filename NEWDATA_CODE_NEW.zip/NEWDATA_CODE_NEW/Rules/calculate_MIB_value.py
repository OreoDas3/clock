def calculate_MIB_value(mib):
    if mib=="Positive Report":
        return "Low Risk"
    elif mib=="Negative Report" :
        return "High Risk"
    else :
        return "None"