def under_writing(policy_status) :
    res= "Declined" if policy_status=="Declined" else "Accepted"
    return res