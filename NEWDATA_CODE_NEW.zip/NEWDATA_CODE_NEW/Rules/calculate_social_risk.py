def calculate_social_risk(status):
    if status == "Active":
        return "Low Risk",1
    elif status == "Non Active":
        return "High Risk",0

