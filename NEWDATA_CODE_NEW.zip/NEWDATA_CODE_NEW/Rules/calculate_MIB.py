from Rules.lib import *
def calculate_MIB(mib):
    if mib=="Positive Report":
        return fake.random_element(elements=('0.9','0.8'))
    elif mib=="Negative Report" :
        return 0.4
    else :
        return 0