def calculate_medical_history_value(family_medical_history):
     #print(family_medical_history)
     if family_medical_history=="Significant History":
         return "High Risk"
     else:
         return "Low Risk"