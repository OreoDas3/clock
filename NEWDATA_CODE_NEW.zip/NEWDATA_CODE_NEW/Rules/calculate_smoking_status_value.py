def calculate_smoking_status_value(smoking_status):
     if smoking_status=="Smoker":
         return "High risk"
     else:
         return "Low risk" 