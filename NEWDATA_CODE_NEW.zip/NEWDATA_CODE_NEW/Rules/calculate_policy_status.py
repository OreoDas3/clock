from datetime import datetime, timedelta

def calculate_policy_status(effective_date, expiry_date, premium_frequency, unpaid_premium_date):
    # Convert input strings to datetime objects
    temp_date = datetime.strptime(expiry_date, "%Y-%m-%d")
    effective_date = datetime.strptime(effective_date, "%Y-%m-%d")
    expiry_date = datetime.strptime(expiry_date, "%Y-%m-%d")
    unpaid_premium_date = datetime.strptime(unpaid_premium_date, "%Y-%m-%d")
    #print(unpaid_premium_date)
    #print(premium_frequency)
    while unpaid_premium_date < temp_date:
        if premium_frequency == "Yearly":
            temp_date -= timedelta(days=365)
        elif premium_frequency == "Half-Yearly":
            temp_date -= timedelta(days=180)
        elif premium_frequency == "Quarterly":
            temp_date -= timedelta(days=90)
        elif premium_frequency == "Monthly":
            temp_date -= timedelta(days=30)
        #print(temp_date)
    due_date = temp_date + timedelta(days=180)
    
    # Check if the unpaid premium date is within the grace period
    if unpaid_premium_date < due_date and temp_date < unpaid_premium_date:
        return "Inforce"
    else:
        return "Lapsed"
