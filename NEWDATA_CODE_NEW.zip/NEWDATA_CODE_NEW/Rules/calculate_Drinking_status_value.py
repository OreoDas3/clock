def calculate_Drinking_status_value(Drinking_status):
     if Drinking_status=="Drinker":
         return "High Risk"
     else:
         return "Low Risk" 