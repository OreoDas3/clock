from Rules.lib import *
def name1(family_medical_history):
    if family_medical_history=="No Significant History":
        return "-"  
    elif family_medical_history=="Significant History" :
        return fake.random_element(elements=('Diabetis','Cancer'))
def desc1(medical_history,family_medical_history):
    if family_medical_history=="No Significant History":
        return "-"
    if medical_history=="Diabetis":
        return "History of Diabetis"
    elif medical_history=="Cancer":
        return "History of Cancer"