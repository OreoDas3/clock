
def calculate_Income_value(Income):
    if Income>=200000:
        return "Excellent"
    elif Income>=150000 and Income<199999:
        return "Very Good"
    elif Income>=100000 and Income<149000:
        return "Good"
    elif Income>=60000 and Income<100000:
        return "Average"
    else:
        return "Bad" 