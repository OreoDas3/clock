def calculate_occupation_risk_value(occpation):
    if occpation=="Policeman":
        return "High Risk"
    elif occpation=="Electrician":
        return "Medium Risk"
    else:
        return "Low Risk"