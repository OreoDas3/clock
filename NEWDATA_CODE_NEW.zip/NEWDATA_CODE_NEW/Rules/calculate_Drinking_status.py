def calculate_Drinking_status(Drinking_status):
    if Drinking_status=="Drinker":
        return 0.5
    else:
        return 0.9