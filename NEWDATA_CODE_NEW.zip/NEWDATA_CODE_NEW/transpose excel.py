import pandas as pd
from openpyxl import load_workbook
# Replace 'your_file.xlsx' with the path to your Excel file
excel_file = r"C:\Users\ronit\projects\NEWDATA_CODE\Risk_Dataset.xlsx"

# Load the Excel file into a Pandas DataFrame
df = pd.read_excel(excel_file)

df_transposed = df.T

# Replace 'transposed_file.xlsx' with the desired output file name
output_file = r"C:\Users\ronit\projects\NEWDATA_CODE\Risk_Dataset_transposed.xlsx"

# Create a Pandas ExcelWriter object
with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
    # Write the transposed DataFrame to the new Excel file
    df_transposed.to_excel(writer, sheet_name='Transposed_Data', index=False)

    # Save the Excel file
    writer._save()
