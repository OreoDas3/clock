from Rules.lib import *
from Rules.calculate_score import *
from Rules.calculate_value import *
from Rules.calculate_Income_score import *
from Rules.calculate_Income_value import  *
from Rules.calculate_smoking_status import *
from Rules.calculate_smoking_status_value import  *
from Rules.calculate_Drinking_status import *
from Rules.calculate_Drinking_status_value import *
from Rules.calculate_occupation_risk import *
from Rules.calculate_occupation_risk_value import *
from Rules.calculate_medical_history import *
from Rules.calculate_medical_history_value import *
from Rules.calculate_MVR import *
from Rules.calculate_MVR_value import *
from Rules.calculate_MIB import *
from Rules.calculate_MIB_value import *
from Rules.calculate_mib_score import *
from Rules.calculate_credit import *
from Rules.bmi import *
from Rules.under_writing import *
from Rules.family_medical_history import *
from Rules.calculate_policy_status import *
from Rules.calculate_social_risk import *
from Details.Variables import random_values
wb=Workbook()
ws=wb.active
ws.column_dimensions['A'].width=20
ws.column_dimensions['B'].width=30
ws.column_dimensions['C'].width=30
rec=int(input("Number of records needed to be generated? "))
print("Processing Starts")

ws['A1']='sl.no'
ws['B1']=''
ws['c1']='details'
for i in range(1,rec+1):
    heading=f"Policy{i}"
    cell=ws.cell(row=1,column=i+3)
    cell.value=heading
for cell in ws[1]:
  cell.font=Font(bold=True)
  cell.alignment=Alignment(horizontal="center")
ws.append([""])
ws.merge_cells('A3:A6')
merged_cell=ws['A3']
merged_cell.value="1"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B3:B6')
merged_cell1=ws['B3']
merged_cell1.value="Policy"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
ws['C3'].value="Policy Number"
ws['C4'].value="Policy Status"
ws['C5'].value="Policy Effective/Declined Date "
ws['C6'].value="Policy Expiry Date"
ws.merge_cells('A8:A12')
merged_cell=ws['A8']
merged_cell.value="2"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B8:B12')
merged_cell1=ws['B8']
merged_cell1.value="Life Assured"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
ws['C8'].value="Surname"
ws['C9'].value="Given Name"
ws['C10'].value="Birth Date"
ws['C11'].value="Gender"
ws['C12'].value="Occupation"
ws.merge_cells('A14:A19')
merged_cell=ws['A14']
merged_cell.value="3"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B14:B19')
merged_cell1=ws['B14']
merged_cell1.value="Address"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
values=[
    "address type","address","city","state province","postal code","country"
]
column='c'
start_row=14
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
ws.merge_cells('A21:A26')
merged_cell=ws['A21']
merged_cell.value="4"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B21:B26')
merged_cell1=ws['B21']
merged_cell1.value="Product"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
values=[
    "product type","product name","Face Amt","Premium Amt","Premium Frequency","First_Unpaid_premium_date"
]
column='c'
start_row=21
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
ws.merge_cells('A28:A29')
merged_cell=ws['A28']
merged_cell.value="5"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B28:B29')
merged_cell1=ws['B28']
merged_cell1.value="carrier"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
values=[
    "carrier name","carrier code"
]
column='c'
start_row=28
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
ws.merge_cells('A31:A33')
merged_cell=ws['A31']
merged_cell.value="6"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B31:B33')
merged_cell1=ws['B31']
merged_cell1.value="agent"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
values=[
    "agent name","agent code","Commission Pct"
]
column='c'
start_row=31
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value 
ws['A35']="7"  
ws['A35'].font=font   
ws['B35']="Underwriting"
ws['B35'].font=font   
values=[
    " Underwriting Decision "
]
column='c'
start_row=35
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value    
ws.merge_cells('A38:A82')
merged_cell=ws['A38']
merged_cell.value="8"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B38:B82')
merged_cell1=ws['B38']
merged_cell1.value="Underwriting Parameters"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
values=[
    "age","value","score"
]
column='c'
start_row=38
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "Income","value","score"
]
column='c'
start_row=42
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "smokingstatus","value","score"
]
column='c'
start_row=46
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "Drinkingstatus","value","score"
]
column='c'
start_row=50
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value    
values=[
    "occupation risk","value","score"
]
column='c'
start_row=54
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "family_medical_history","value","score"
]
column='c'
start_row=58
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "bmi","height","weight","value","score"
]
column='c'
start_row=62
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "mvr","value","score"
]
column='c'
start_row=68
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "mib","value","score"
]
column='c'
start_row=72
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value    
values=[
    "credit_rating","value","score"
]
column='c'
start_row=76
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
values=[
    "social_media","value","score"
]
column='c'
start_row=80
for index,value in enumerate(values):
    ws[column+str(start_row+index)].value=value
ws.merge_cells('A84:A85')
merged_cell=ws['A84']
merged_cell.value="9"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws.merge_cells('B84:B85')
merged_cell1=ws['B84']
merged_cell1.value="Adverse Medical Details"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
ws['C84'].value="name"
ws['C85'].value="discription"
ws.merge_cells('B87:B89')
merged_cell1=ws['B87']
merged_cell1.value="Claim Details"
merged_cell1.alignment=Alignment(horizontal='center',vertical='center')
merged_cell1.font=font
ws.merge_cells('A87:A89')
merged_cell=ws['A87']
merged_cell.value="10"
merged_cell.alignment=Alignment(horizontal='center',vertical='center')
font=Font(bold=True)
merged_cell.font=font
ws['C87'].value="Date of Death"
ws['C88'].value="Date of Claim settlement"
ws['C89'].value="Cause of Death "

for i in range(1,rec+1):  # Generating 100 records (1,11) 1-10
    print(i)
    for row in ws.iter_rows(min_row=3,max_row=ws.max_row):
        for cell in row:
            cell.alignment=Alignment(horizontal="center")
    
    tup= random_values()
    policy_number = tup[0]
    random_year = tup[1]
    month = tup[2]
    day = tup[3]
    policy_effective_date = tup[4]
    medical_history=tup[5]
    policy_expiry_date=tup[6]
    Surname=tup[7]
    given_name=tup[8]
    birthdate = tup[9]
    Gender=tup[10]
    occupation=tup[11]
    address_type=tup[12]
    address=fake.random_element(elements=('3543 Upland Avenue','1715 Ashmor Drive',' 3656 Neuport Lane','1283 Bobcat Drive',' 1939 Longview Avenue','2815 Burke Street',' 728 Pooh Bear Lane',' 4719 Farland Avenue','1373 Oliver Street','4586 Ritter Street','881 Gladwell Street','2610 New Street'))
    city=tup[13]
    state_province=tup[14]
    postal_code=tup[15]
    country='US'
    product_type='Term'
    product_name='Term Life Insurance - 20'
    Face_Amt=tup[16]
    Premium_Amt=tup[17]
    Premium_Frequency=tup[18]
    First_Unpaid_premium_date=tup[19]
    age = tup[20]
    policy_status=tup[21]
    under_writing_decision=tup[22]
    carrier_name=fake.random_element(elements=("The Guardian Life Insurance Company of America","The Chubb Corporation"))
    carrier_code=fake.random_element(elements=('abc123','def456','ghi789','jkl012','mn0345','pqr678','stu987','vwx908'))
    Agency_name=fake.random_element(elements=('American Family Insurance','Lincoln National Corporation ','General Reinsurance Corporation ',' Willis Towers Watson PLC   ',' AmTrust Financial Services ','USI Insurance Services LLC   '))
    Agent_code=fake.random_element(elements=('abc123','def456','ghi789','jkl012','mn0345','pqr678','stu987','vwx908'))
    Commission_Pct='10.5'
    Income=tup[23]
    smoking_status=tup[24]
    Drinking_status=tup[25]
    family_medical_history=tup[26]
    height=tup[27]
    weight=tup[28]
    mvr=tup[29]
    mib=tup[30]
    value=tup[31]
    social_media=tup[32]
    #fake.random_element(elements=('presence','non presence'))
    # start_date =policy_effective_date

    cell=ws.cell(row=3,column=i+3)  
    cell.value=  str(policy_number)
    cell=ws.cell(row=4,column=i+3)
    cell.value=  policy_status        
    cell=ws.cell(row=5,column=i+3)
    cell.value=str(policy_effective_date)
    cell=ws.cell(row=6,column=i+3)
    cell.value=  str(policy_expiry_date)
    cell=ws.cell(row=8,column=i+3)  
    cell.value=str(policy_expiry_date)
    cell=ws.cell(row=8,column=i+3) 
    cell.value=  Surname
    cell=ws.cell(row=9,column=i+3)  
    cell.value= given_name
    cell=ws.cell(row=10,column=i+3)  
    cell.value= str(birthdate)
    cell=ws.cell(row=11,column=i+3)  
    cell.value=Gender
    cell=ws.cell(row=12,column=i+3)  
    cell.value=occupation
    cell=ws.cell(row=14,column=i+3)  
    cell.value=address_type
    cell=ws.cell(row=15,column=i+3)  
    cell.value=address
    cell=ws.cell(row=16,column=i+3)  
    cell.value=city
    cell=ws.cell(row=17,column=i+3)  
    cell.value=state_province
    cell=ws.cell(row=18,column=i+3)  
    cell.value=str(postal_code)
    cell=ws.cell(row=19,column=i+3)  
    cell.value=country
    cell=ws.cell(row=21,column=i+3)  
    cell.value=product_type
    cell=ws.cell(row=22,column=i+3)  
    cell.value=product_name
    cell=ws.cell(row=23,column=i+3)  
    cell.value=str(Face_Amt)
    cell=ws.cell(row=24,column=i+3)  
    cell.value=str(Premium_Amt)
    cell=ws.cell(row=25,column=i+3)  
    cell.value=Premium_Frequency
    cell=ws.cell(row=26,column=i+3)
    cell.value=First_Unpaid_premium_date
    cell=ws.cell(row=28,column=i+3)
    cell.value=str(carrier_name)
    cell=ws.cell(row=29,column=i+3)  
    cell.value=carrier_code
    cell=ws.cell(row=31,column=i+3)  
    cell.value=Agency_name
    cell=ws.cell(row=32,column=i+3)  
    cell.value=Agent_code
    cell=ws.cell(row=33,column=i+3)  
    cell.value=Commission_Pct
    cell=ws.cell(row=35,column=i+3)
    cell.value=under_writing_decision
    cell=ws.cell(row=42,column=i+3) 
    cell.value=str(Income)
    cell=ws.cell(row=43,column=i+3)  
    cell.value=calculate_Income_value(Income)
    cell=ws.cell(row=44,column=i+3)  
    cell.value=calculate_Income_score(Income)
    cell=ws.cell(row=38,column=i+3)  
    cell.value=str(age)
    cell=ws.cell(row=39,column=i+3)  
    cell.value=calculate_value(age)
    cell=ws.cell(row=40,column=i+3)  
    cell.value=calculate_score(age)
    cell=ws.cell(row=46,column=i+3)  
    cell.value=str(smoking_status)
    cell=ws.cell(row=47,column=i+3)  
    cell.value=calculate_smoking_status_value(smoking_status)
    cell=ws.cell(row=48,column=i+3)  
    cell.value=calculate_smoking_status(smoking_status)
    cell=ws.cell(row=50,column=i+3)
    cell.value=str(Drinking_status)
    cell=ws.cell(row=51,column=i+3) 
    cell.value=calculate_Drinking_status_value(Drinking_status)
    cell=ws.cell(row=52,column=i+3)  
    cell.value=calculate_Drinking_status(Drinking_status)
    cell=ws.cell(row=55,column=i+3)  
    cell.value=calculate_occupation_risk_value(occupation)
    cell=ws.cell(row=56,column=i+3)  
    cell.value=calculate_occupation_risk(occupation)
    
    cell=ws.cell(row=58,column=i+3)  
    cell.value=str(family_medical_history)
    cell=ws.cell(row=59,column=i+3)  
    cell.value=calculate_medical_history_value(family_medical_history)
    cell=ws.cell(row=60,column=i+3)  
    cell.value=calculate_medical_history(family_medical_history)
    
    cell=ws.cell(row=63,column=i+3)  
    cell.value=height
    cell=ws.cell(row=64,column=i+3)  
    cell.value=weight
    cell=ws.cell(row=65,column=i+3)  
    cell.value=calculate_height(height,weight)
    cell=ws.cell(row=66,column=i+3)  
    cell.value=calculate_height_value(height,weight)
    cell=ws.cell(row=68,column=i+3)  
    cell.value=str(mvr)
    cell=ws.cell(row=69,column=i+3)  
    cell.value=calculate_MVR_value(mvr)
    cell=ws.cell(row=70,column=i+3)  
    cell.value=calculate_MVR(mvr)
    cell=ws.cell(row=72,column=i+3)  
    cell.value=str(mib)
    cell=ws.cell(row=73,column=i+3)  
    cell.value=calculate_MIB_value(mib)
    cell=ws.cell(row=74,column=i+3)  
    cell.value=calculate_MIB(mib)
    #CREDIT SCORE
    cell=ws.cell(row=76,column=i+3)  
    cell.value=value
    credit_value,credit_score=calculate_credit(value)
    cell=ws.cell(row=77,column=i+3)  
    cell.value=credit_value
    cell=ws.cell(row=78,column=i+3)  
    cell.value= credit_score
    
    #SOCIAL MEDIA
    cell=ws.cell(row=80,column=i+3)  
    cell.value=social_media
    social_risk_value,social_risk_score=calculate_social_risk(social_media)
    cell=ws.cell(row=81,column=i+3)  
    cell.value=social_risk_value
    cell=ws.cell(row=82,column=i+3)  
    cell.value=social_risk_score
    
    cell=ws.cell(row=84,column=i+3)
    cell.value=(name1(family_medical_history))
    cell=ws.cell(row=85,column=i+3)
    cell.value=desc1(medical_history,family_medical_history)
    cell=ws.cell(row=87,column=i+3)
    cell.value=tup[33]
    cell=ws.cell(row=88,column=i+3)
    cell.value=tup[34]
    cell=ws.cell(row=89,column=i+3)
    cell.value=tup[35]
    cell=ws.cell(row=90,column=i+3)
    ws.column_dimensions[cell.column_letter].width = 50
    wb.save('Risk_Dataset.xlsx')

print("Dataset Successfully Generated and to saved Risk_Dataset.xlsx")